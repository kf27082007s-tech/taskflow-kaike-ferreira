---
name: TaskFlow Atividade
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3f4850'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#707881'
  outline-variant: '#bfc7d2'
  surface-tint: '#006398'
  primary: '#006194'
  on-primary: '#ffffff'
  primary-container: '#007bb9'
  on-primary-container: '#fdfcff'
  inverse-primary: '#93ccff'
  secondary: '#00668a'
  on-secondary: '#ffffff'
  secondary-container: '#40c2fd'
  on-secondary-container: '#004d6a'
  tertiary: '#545c72'
  on-tertiary: '#ffffff'
  tertiary-container: '#6c748b'
  on-tertiary-container: '#fefcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The visual identity embodies a clean, utilitarian, and ergonomic operational aesthetic tailored for field maintenance technicians and facilities managers. It combines structured clarity with crisp modern minimalism, ensuring operational fatigue is reduced while processing dense backlogs and complex work orders.

The tone is dependable, efficient, and precise. The design style relies on a modern corporate SaaS foundation: crisp white card surfaces against cool slate backgrounds, high-contrast readable type, subtle structural borders, and purposeful sky-blue accents that denote actionability and real-time state changes without overwhelming the workspace.

## Colors

The palette is engineered around high functional clarity, systematic prioritization, and light operational hygiene:

- **Primary (`#0284c7`)**: Directs focus toward primary actions, active filters, and primary status indicators. Paired with light tint containers (`#e0f2fe`, `#f0f9ff`) for soft highlights.
- **Secondary (`#38bdf8`)**: Used for supplementary telemetry, interactive focus states, and badge accents.
- **Surfaces & Canvases**: Base application canvas rests on clean light slates (`#f8fafc` to `#f1f5f9`), while active working components, cards, and modal sheets use pure white (`#ffffff`).
- **Typography & Neutrals**: Headings and primary data points leverage deep slate (`#0f172a`), secondary labels sit on dark neutral (`#1e293b`), and supporting metadata, borders, and placeholders use mid-to-light grays (`#64748b` and `#e2e8f0`).
- **Functional Semantics**:
  - Urgent/Critical: `#ef4444` (Surface: `#fef2f2`)
  - In Progress: `#0284c7` (Surface: `#e0f2fe`)
  - Awaiting Parts/Review: `#f59e0b` (Surface: `#fffbeb`)
  - Resolved/Completed: `#10b981` (Surface: `#ecfdf5`)

## Typography

Typography relies uniformly on `Inter` to deliver exceptional tabular legibility, rigid vertical alignment, and predictable sizing across dense maintenance tables and ticket cards.

- Headings (`headline-xl`, `headline-lg`) establish direct structural anchors for board views and dialog headers.
- Work order titles and card identifiers use `headline-md` and `label-lg` to allow quick parsing during rapid scrolling.
- Body scales are tuned for dense information intake: `body-md` handles standard descriptions and input values, while `body-sm` and `label-sm` govern timestamps, serial numbers, metadata tags, and micro-copy.

## Layout & Spacing

The layout is built on an adaptable 8pt coordinate system focused on maximizing horizontal real estate for board swimlanes and detail sidebars.

- **Desktop (Kanban & Table Views)**: Uses a fluid horizontal scrolling board with fixed column widths (`280px` to `320px`) and `1rem` column gutters. Modals appear centered with explicit `600px` to `800px` widths or slide over as a `480px` drawer from the right.
- **Mobile (Handheld Field Mode)**: Single-column stacked layout with swipeable tabs for Kanban columns. Container margins reduce to `margin-mobile` (`1rem`) to preserve space for ticket summaries, asset tags, and photo attachment actions.
- **Rhythm**: Inner component padding adheres strictly to `space-sm` (`0.5rem`) for compact tags and inputs, `space-md` (`1rem`) for standard cards, and `space-lg` (`1.5rem`) for modal body sections.

## Elevation & Depth

Visual hierarchy uses a refined hybrid approach combining subtle, ambient slate drop shadows with 1px hairline borders (`#e2e8f0`). Heavy elevation is avoided in favor of clarity and clean visual layering:

- **Level 0 (Flat Canvas)**: Surface background in `#f8fafc`. No shadow.
- **Level 1 (Kanban Cards & Form Controls)**: Pure white `#ffffff` fill with a `1px` border in `#e2e8f0` and an ambient shadow (`0 1px 2px 0 rgba(15, 23, 42, 0.05)`).
- **Level 2 (Hovered Cards & Dropdowns)**: White `#ffffff` fill, border tinted to `#cbd5e1`, with elevated shadow (`0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)`).
- **Level 3 (Modals & Sheet Drawers)**: High elevation modal surfaces supported by a semi-transparent dark backdrop (`rgba(15, 23, 42, 0.4)`), bordered in `#e2e8f0` with a deep ambient shadow (`0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`).

## Shapes

The geometric personality balances soft modern ergonomics with systematic precision. 

With roundedness set to `2`, baseline interactive elements (buttons, text fields, checkboxes) adopt a clean `0.5rem` radius. Larger structural containers—specifically Kanban ticket cards and modal dialogs—utilize `rounded-lg` (`1rem`) and `rounded-xl` (`1.5rem`) to create smooth, polished focal regions. Status pills and count badges employ full circular pill finishes to contrast against orthogonal card bounds.

## Components

### Buttons
- **Primary**: Solid `#0284c7` background, `#ffffff` text, font weight 600, `0.5rem` border radius, subtle inner highlight. Hover state transitions to `#0369a1`.
- **Secondary / Outline**: Transparent fill, 1px border `#e2e8f0`, `#0f172a` text. Hover shifts background to `#f1f5f9`.
- **Subtle / Ghost**: Transparent fill, `#64748b` text. Used for secondary card actions and close icons.

### Status Badges & Chips
- Compact pills with `4px 10px` padding, uppercase `label-sm` tracking.
- Composed of paired 10% opacity surface fills with solid text:
  - *Em Aberto / Triagem*: Background `#f0f9ff`, Text `#0284c7`, Border `#bae6fd`.
  - *Em Manutenção*: Background `#e0f2fe`, Text `#0369a1`, Border `#7dd3fc`.
  - *Pendente Peça*: Background `#fffbeb`, Text `#b45309`, Border `#fde68a`.
  - *Concluído*: Background `#ecfdf5`, Text `#047857`, Border `#a7f3d0`.

### Kanban Cards
- Container: White `#ffffff`, border `1px solid #e2e8f0`, radius `rounded-lg` (`1rem`), padding `space-md` (`1rem`).
- Header: Ticket ID (`label-sm`, `#64748b`) paired with priority indicator chip.
- Content: Work order title in `headline-md` or `label-lg` (`#0f172a`), followed by asset/location tag.
- Footer: Assignee avatar circle (24px) paired with due date micro-copy and attachment counter.

### Input Fields & Controls
- Height: 40px (desktop), 44px (mobile touch target).
- Border: `1px solid #e2e8f0`, background `#ffffff`, radius `0.5rem`.
- Focus state: Outline replacement with `2px solid #0284c7` and box shadow `0 0 0 3px rgba(56, 189, 248, 0.25)`.

### Modals & Drawers (Detail & Creation)
- Backdrop: `rgba(15, 23, 42, 0.45)` with light backdrop blur (`4px`).
- Modal Card: Surface `#ffffff`, radius `rounded-xl` (`1.5rem`), border `1px solid #e2e8f0`.
- Divided into pinned Header (Title + Ticket Status badge + Close), scrollable body with dual-column meta layouts (Machine/Asset, SLA, Assigned Technician, Checklist), and sticky action footer.